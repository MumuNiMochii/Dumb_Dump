<?php
	include 'connection.php';

    $dbName = "epiz_26810500_nfposts";
	$connection = mysqli_connect($dbServerName, $dbUsername, $dbPassword, $dbName);

	$nfpostNewCount = $_POST['nfpostNewCount'];
	
	$sql = "SELECT * FROM news ORDER BY id DESC";
	$result = mysqli_query($connection, $sql);
	if (mysqli_num_rows($result) > 0) {
		while ($row = mysqli_fetch_assoc($result)) {
            echo "<style>
                #mainTable {
                    margin: 20px 10% 20px 10%;
                    width: 80%;
                    background-color: #1a1a1a;
                    border: none;
                    border-radius: 6px;
                    display: grid;
                }
                #divbase {
                    display: grid;
                    grid-template-columns: 100%;
                    grid-template-rows: auto auto auto auto auto;
                    border: 1px solid transparent;
                    border-radius: 6px;
                }
                #mainTr {
                    display: grid;
                    grid-template-columns: auto;
                    grid-template-rows: auto;
                }
                #R1_C1 {
                    display: grid;
                    grid-template-columns: 80% 20%;
                    grid-template-rows: auto;
                    padding: 10px;
                    border-top-left-radius: 6px;
                    border-top-right-radius: 6px;
                    border: 1px solid transparent;
                    background-color: #262626;
                }
                #R1_C1_1 {
                    font-size: 20px;
                }
                #R1_C1_2 {
                    font-size: 14px;
                    text-align: right;
                }
                #R2_C1 {
                    padding: 2px 10px 2px 10px;
                    border: 1px solid transparent;
                    border-bottom-left-radius: 6px;
                    border-bottom-right-radius: 6px;
                    background-color: #333333;
                    font-size: 12px;
                    font-style: italic;
                    display: grid;
                    grid-template-columns: 100%;
                    grid-template-rows: auto;
                }
                #R3_C1 {
                    margin: 10px;
                    padding: 10px;
                    border-radius: 6px;
                    border: 1px solid #404040;
                    background-color: #111;
                    display: grid;
                    grid-template-columns: 100%;
                    grid-template-rows: auto;
                }
                #R1_C1_1, #R2_C1_1, #R1_C1_2, #R3_C1_1 {
                    display: inline-block;
                }
                #divbase:hover {
                    background-color: #262626;
                    border: 1px solid #55f7ce;
                }
                #divbase:hover > #R1_C1 {
                    background-color: #333333;
                }
                #divbase:hover > #R2_C1 {
                    background-color: #404040;
                }
                #commentForm {
                    display: grid;
                    grid-template-columns: 100%;
                    grid-template-rows: auto;
                }
                #commentFormL {
                    padding: 10px;
                }
                #inputComment {
                    width: 100%;
                    padding: 15px 10px 0px 10px;
                    border: 1px solid transparent;
                    border-radius: 20px;
                    background-color: #111;
                }
                #inputComment:hover, #inputComment:focus {
                    border: 1px solid #55f7ce;
                }
            </style>";
			echo "<table id='mainTable'>
				    <tr id='mainTr'>
                        <td>
                            <div id='divbase'>
                                            <div id='R1_C1'><div id='R1_C1_1'>".$row['subject']."</div><div id='R1_C1_2'>".$row['userid']."</div></div>
                                            <div id='R2_C1'><div id='R2_C1_1'><p>".$row['tags']."</p></div></div>
                                            <div id='R3_C1'><div id='R3_C1_1'><p>".$row['story']."</p></div></div>
                                            <!-- comment span div START -->
                                                <div id='R5_C1'>
                                                    <p id='uCommentP' name='uCommentShow'>
                                                      <!-- new comments will nest here -->
                                                    </p>
                                                </div>
                                                <!-- comment span div END -->

                                            <div id='R4_C1'>
                                                <!-- comment bar START -->
                                                <div id='R4_C1_1'>
                                                    <form id='commentForm'>
                                                        <div id='commentFormL'>
                                                            <textarea id='inputComment' name='inputCommentN' placeholder='Share some sharks:'></textarea>
                                                        </div>
                                                    </form>
                                                </div>
                                                <!-- comment bar END -->
                                            </div>
                            </div>
                        </td>
                    </tr>
			    </table>";
		}
	} else {
		echo "There are no posts.";
	}
?>