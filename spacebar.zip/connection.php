<?php
	//establish connection to the server and db
	$dbServerName = "sql208.epizy.com";
	$dbUsername = "epiz_26810500";
	$dbPassword = "rQz6dbux0sLrkz";
?>