<?php
    include 'connection.php';
    /* include '/home/voIl0_5/epizy.com/epiz_26810500/htdocs/imgPost/';*/

    $dbName = "epiz_26810500_nfposts";
	$connection = mysqli_connect($dbServerName, $dbUsername, $dbPassword, $dbName);

    $select = mysqli_select_db($connection, $dbName); //select db from established connection
	//with $connection and $select === [string host, string username, string passwd, dbname]
	
	$dollarStr = "$";//'$' string; in able to be included within another string
	
	//check if connection to server is established
	if (!$connection) {
		echo $dollarStr."connection status: Not connected to server<br>";
	}
	else {
		echo $dollarStr."connection status: Connected to the server<br>";
		//check if database is selected
		if (!$select) {
		    echo $dollarStr."dbName status: Database not selected<br>";
        }
		else {
			echo $dollarStr."dbName status: Database selected<br>";

            $userid = $_POST["nfPost_ID"];
			$subject = $_POST["nfPost_subject"];    //must be bracket instead of parenthesis
			$story = $_POST["nfPost_story"];	    //in order to be read as a string
			$tags = $_POST["nfPost_tags"];		    //instead of a function

            if (empty($subject) || empty($story) && empty($tags)) {
                //where all textarea are empty
                echo $dollarStr."postForm status: Not inserted<br>";
            }
            elseif (!empty($subject) || !empty($story) || !empty($tags)) {
                //where all textarea are not empty
                $postForm = "INSERT INTO news (userid, subject, story, tags) VALUES ('$userid', '$subject', '$story', '$tags');";
            }
            elseif (!empty($subject) || !empty($story) || empty($tags)) {
                //where only 'Tags' is empty
                $postForm = "INSERT INTO news (userid, subject, story, tags) VALUES ('$userid', '$subject', '$story', '$tags');";
            }
            else {
                //where neither subject nor story must be excluded
                echo $dollarStr."postForm status: Not inserted<br>";
            }

			if (!mysqli_query($connection,$postForm)) {
				echo $dollarStr."postForm status: Not inserted<br>";
			}
			else {
                echo $dollarStr."postForm status: Inserted<br>";

                if (empty($subject) || empty($story) && empty($tags)) {
                    //where all textarea are empty
                    echo $dollarStr."postForm status: Not inserted<br>";
                }
                elseif (!empty($subject) || !empty($story) || !empty($tags)) {
                    //where all textarea are not empty
                    $postForm = "INSERT INTO news (userid, subject, story, tags) VALUES ('$userid', '$subject', '$story', '$tags');";
                }
                elseif (!empty($subject) || !empty($story) || empty($tags)) {
                    //where only 'Tags' is empty
                    $postForm = "INSERT INTO news (userid, subject, story, tags) VALUES ('$userid', '$subject', '$story', '$tags');";
                }
                else {
                    //where neither subject nor story must be excluded
                    echo $dollarStr."postForm status: Not inserted<br>";
                }
            }
        }
    }

	header("refresh:0; url=index.html");  
?>