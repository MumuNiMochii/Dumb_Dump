<?php
    if (!empty($_SERVER["REMOTE_ADDR"])) {
        $userIP = $_SERVER["REMOTE_ADDR"];
    }
    //otherwise if computer IP isn't present
    elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
        $userIP = $_SERVER["HTTP_X_FORWARDED_FOR"];
    }
    elseif (!empty($_SERVER["HTTP_CLIENT_IP"])) {
        $userIP = $_SERVER["HTTP_CLIENT_IP"];
    }
    else {
        echo "Error: User cannot be given with unique address.";
    }

    //user's unique anonymous ID - uTokenCoin
    //basic algorithm but I still have to improvise this on my notebook
    
    //split $userIP into an array
    $uIPSplit = (str_split($userIP));

    //remove dot from array and sort elements
    $uToken1 = array_diff($uIPSplit, array('.'));
    krsort($uToken1);

    //remove elements: 1 from front and 5 from last
    $uToken1Slice = array_slice($uToken1, 1, 5);

    //declare another uToken*
    $uToken2 = array_diff($uIPSplit, array('.'));
    ksort($uToken2);

    //remove 6 elements from right side and sort
    $uToken2Slice = array_slice($uToken2, 6);
    asort($uToken2Slice);

    //declare third uToken
    $uToken3 = array_diff($uIPSplit, array('.'));
    asort($uToken3);

    //remove 5
    $uToken3Slice = array_slice($uToken3, 0, 5);
    krsort($uToken3Slice);

    //declare 'splitter' array and merge all arrays
    $a = array("-");
    $uTokenMerge = array_merge($uToken1Slice, $a, $uToken2Slice, $a, $uToken3Slice);

    //implode array into string primitive data type
    $uTokenCoin = implode($uTokenMerge);
    echo $uTokenCoin;
?>